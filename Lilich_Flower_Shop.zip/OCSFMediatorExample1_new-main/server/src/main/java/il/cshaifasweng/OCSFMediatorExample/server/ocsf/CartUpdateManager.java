package il.cshaifasweng.OCSFMediatorExample.server.ocsf;
import il.cshaifasweng.OCSFMediatorExample.server.SimpleServer;
import il.cshaifasweng.OCSFMediatorExample.entities.*;

import il.cshaifasweng.OCSFMediatorExample.server.ocsf.AbstractServer;
import il.cshaifasweng.OCSFMediatorExample.server.ocsf.ConnectionToClient;
//import il.cshaifasweng.OCSFMediatorExample.server.Product;
import java.io.IOException;
import java.sql.DatabaseMetaData;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;

import org.hibernate.*;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.service.ServiceRegistry;

import javax.persistence.EntityManager;
import javax.persistence.PreUpdate;
import javax.persistence.TypedQuery;
import javax.persistence.criteria.CriteriaBuilder;
import javax.persistence.criteria.CriteriaQuery;
import javax.persistence.criteria.Root;
import javax.swing.*;

public class CartUpdateManager {/*
    public static int cartsnum = 0;
    public static List<Cart> cartGeneralList = new ArrayList<Cart>();

    private static List<Cart> getAllCarts() {
        System.out.println("Arrived to getAllCarts 1");
        CriteriaBuilder builder = SimpleServer.session.getCriteriaBuilder();
        System.out.println("Arrived to getAllCarts 2");
        CriteriaQuery<Cart> query = builder.createQuery(Cart.class);
        System.out.println("Arrived to getAllCarts 3");
        query.from(Cart.class);
        System.out.println("Arrived to getAllCarts 4");
        List<Cart> result = SimpleServer.session.createQuery(query).getResultList();
        System.out.println("Arrived to getAllCarts 5");
        return result;
    }

    static Long countRowsCart() {
        System.out.println("Arrived to coutnrwos 1");
        final CriteriaBuilder criteriaBuilder = SimpleServer.session.getCriteriaBuilder();
        System.out.println("Arrived to coutnrwos 2");
        CriteriaQuery<Long> criteria = criteriaBuilder.createQuery(Long.class);
        System.out.println("Arrived to coutnrwos 3");
        Root<Cart> root = criteria.from(Cart.class);
        System.out.println("Arrived to coutnrwos 4");
        criteria.select(criteriaBuilder.count(root));
        System.out.println("Arrived to coutnrwos 5");
        return SimpleServer.session.createQuery(criteria).getSingleResult();
    }

    public static void addCart(Cart recievedCart) {
        System.out.println("inside additemTocatalog1");

        long numOfRowsCart = countRowsCart();
        int castedId = (int) numOfRowsCart;
        int newCartId = castedId + 1;
        recievedCart.setCartID(newCartId);
        System.out.println("inside additemTocatalog2");
        int recievedCartTotalPrice = recievedCart.getTotalPrice();
        System.out.println("inside additemTocatalog3");
        int recievedCartTotalPriceDis = recievedCart.getTotalpriceDiscount();
        System.out.println("inside additemTocatalog4");
        Account recievedCartAccount = recievedCart.getCartAccount();
        System.out.println("inside additemTocatalog5");
        ///////////////////////////////////////////////////List<Product> recievedCartProducts = recievedCart.getCartProducts();

        SessionFactory sessionFactory = SimpleServer.getSessionFactory();
        SimpleServer.session = sessionFactory.openSession();
        Transaction tx = SimpleServer.session.beginTransaction();
        System.out.println("inside additemTocatalog8");
        System.out.println("the new index is:" + newCartId);

        SimpleServer.session.save(recievedCart);
        System.out.println("inside additemTocatalog9");
        SimpleServer.session.flush();
        System.out.println("inside additemTocatalog10");
        tx.commit();
        System.out.println("inside additemTocatalog11");

        System.out.println("inside additemTocatalog12");
    }

    public static void removeCart(String cartIdToRemove, ConnectionToClient _client) {


        System.out.println("arrived to removeCart");

        SessionFactory sessionFactory = SimpleServer.getSessionFactory();
        SimpleServer.session = sessionFactory.openSession();
        Transaction tx = SimpleServer.session.beginTransaction();


        cartsnum--;

        int removedId = Integer.parseInt(cartIdToRemove);
        cartGeneralList = getAllCarts();
        cartGeneralList.remove(removedId-1); // remove the wanted item from the list
        for(int i=0;i<cartGeneralList.size();i++){ // update all the items id's
            if(cartGeneralList.get(i).getCartID() > removedId){
                cartGeneralList.get(i).setCartID((cartGeneralList.get(i).getCartID()-1));
            }
        }
        System.out.println("arrived to removeCart 2");


        SimpleServer.session = sessionFactory.openSession();
        Transaction tx1 = SimpleServer.session.beginTransaction();
        long longID = countRowsCart();
        SimpleServer.session.close();
        //tx1.commit();
        System.out.println("arrived to removeCart 3 and the longID is " + longID);
        int castedID = (int) longID;
        for(int l=0;l<castedID;l++){

            System.out.println("arrived to removeItemFromCatalog 2.5");
            deleteCart(l+1);
        }

        SimpleServer.session = sessionFactory.openSession();
        Transaction tx2 = SimpleServer.session.beginTransaction();
        for(int i=0;i<cartGeneralList.size();i++){
            SimpleServer.session.save(cartGeneralList.get(i));
            SimpleServer.session.flush();
        }
        tx2.commit();
        SimpleServer.session.close();

        //session.close(); // here we finished deleting a cart, everything else is for updating the id's
        System.out.println("arrived to removeItemFromCatalog 2.8");

    }

    public static void deleteCart(int deleteIndex) {
        System.out.println("arrived to deleteCart 1");
        SessionFactory sessionFactory = SimpleServer.getSessionFactory();
        SimpleServer.session = sessionFactory.openSession();
        Transaction tx = SimpleServer.session.beginTransaction();
        System.out.println("arrived to deleteCart 2");

        Object persistentInstance = SimpleServer.session.load(Cart.class, deleteIndex);
        Cart perCart = (Cart) persistentInstance;
        System.out.println("arrived to deleteCart 3");
        if (persistentInstance != null) {
            SimpleServer.session.delete(perCart);
        }
        System.out.println("arrived to deleteProd 4");

        tx.commit();
        SimpleServer.session.close();

    }

    public static int calcPriceDiscount(Cart cart){
        int discount, priceDiscount;
        if(cart.getCartAccount().isSubscription() && (cart.getTotalPrice()>50))
            discount =10;
        else
            discount =0;
        priceDiscount= cart.getTotalPrice()-(cart.getTotalPrice()*discount/100);
        cart.setTotalpriceDiscount(priceDiscount);
        return priceDiscount;
    }*/
}
