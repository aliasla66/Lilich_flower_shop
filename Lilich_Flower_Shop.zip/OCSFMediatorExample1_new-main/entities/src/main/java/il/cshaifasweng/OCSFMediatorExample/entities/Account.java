package il.cshaifasweng.OCSFMediatorExample.entities;

import javax.persistence.*;
import java.io.Serializable;
import java.util.Date;
import java.util.List;

@Entity
@Table(name = "accounts_table")
public class Account implements Serializable {

    @Id
    private int accountID;
    @Column(name = "Full_Name")
    private String fullName;
    @Column(name = "Address")
    private String address;                 // Privilage 0 = GUEST
    @Column(name = "Email")                 // Privilage 1 = Customer
    private String email;                   // Privilage 2 = Worker
    @Column(name = "Passowrd")              // Privilage 3 = Manager
    private String password;                // Privilage 4 = Chain Manager
    @Column(name = "Phone_Number")
    private long phoneNumber;
    @Column(name = "Credit_Card_Number")
    private long creditCardNumber;
    @Column(name = "Expire_Date")
    private Date creditCardExpire;
    @Column(name = "CVV")
    private int ccv;
    @Column(name = "Logged_In")
    private Boolean loggedIn;
    /*@ManyToMany
    @JoinTable(
            name = "products_cart",
            joinColumns = @JoinColumn(name = "AccountID", referencedColumnName = "accountID"),
            inverseJoinColumns = @JoinColumn(name = "product_ID", referencedColumnName = "id")
    )
    private List<Product> cartProducts;*/
    private int totalPriceDiscount;
    private int totalPrice;

    //private List<Complaint> accountComplaints = new List<Complaint>;
    //private List<Order> accountOrders = new List<Order>;
    /*@OneToOne(optional = false)
    @JoinColumn(name = "Cart_ID", referencedColumnName = "cartID")
    private Cart accCart;*/
    /*@OneToMany
    @JoinColumn(name="Account_ID",referencedColumnName = "accountID")
    private List<Order> AccountOrders;**/
    private int belongShop;
    private boolean isSubscription;


    public Account(String fullName, String address, String email, String password, long phoneNumber, long creditCardNumber, Date creditCardExpire, int ccv, Boolean loggedIn, List<Order> accountOrders, int belongShop, boolean isSubscription) {
        this.fullName = fullName;
        this.address = address;
        this.email = email;
        this.password = password;
        this.phoneNumber = phoneNumber;
        this.creditCardNumber = creditCardNumber;
        this.creditCardExpire = creditCardExpire;
        this.ccv = ccv;
        this.loggedIn = loggedIn;
        //this.accCart = accCart;
        //AccountOrders = accountOrders;
        this.belongShop = belongShop;
        this.isSubscription = isSubscription;
        this.totalPriceDiscount = 0;
        this.totalPrice =0;
    }

    public Account() {

    }

    public void setAccountID(int accountID) {
        this.accountID = accountID;
    }

    public void setFullName(String fullName) {
        this.fullName = fullName;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setPhoneNumber(long phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public void setCreditCardNumber(long creditCardNumber) {
        this.creditCardNumber = creditCardNumber;
    }

    public void setCreditCardExpire(Date creditCardExpire) {
        this.creditCardExpire = creditCardExpire;
    }

    public void setCcv(int ccv) {
        this.ccv = ccv;
    }

    public void setLogged(Boolean logged) {
        this.loggedIn = logged;
    }

    public void setBelongShop(int belongShop) {
        this.belongShop = belongShop;
    }

    public int getAccountID() {
        return accountID;
    }

    public String getFullName() {
        return fullName;
    }

    public String getAddress() {
        return address;
    }

    public String getEmail() {
        return email;
    }

    public String getPassword() {
        return password;
    }

    public long getPhoneNumber() {
        return phoneNumber;
    }

    public long getCreditCardNumber() {
        return creditCardNumber;
    }

    public Date getCreditCardExpire() {
        return creditCardExpire;
    }

    public int getCcv() {
        return ccv;
    }

    public Boolean getLogged() {
        return loggedIn;
    }

    public int getBelongShop() {
        return belongShop;
    }

    public boolean isSubscription() {
        return isSubscription;
    }

    public void setSubscription(boolean subscription) {
        isSubscription = subscription;
    }

    public Boolean getLoggedIn() {
        return loggedIn;
    }

    public void setLoggedIn(Boolean loggedIn) {
        this.loggedIn = loggedIn;
    }

    public int getTotalPriceDiscount() {
        return totalPriceDiscount;
    }

    public void setTotalPriceDiscount(int totalPriceDiscount) {
        this.totalPriceDiscount = totalPriceDiscount;
    }

    public int getTotalPrice() {
        return totalPrice;
    }

    public void setTotalPrice(int totalPrice) {
        this.totalPrice = totalPrice;
    }
}
