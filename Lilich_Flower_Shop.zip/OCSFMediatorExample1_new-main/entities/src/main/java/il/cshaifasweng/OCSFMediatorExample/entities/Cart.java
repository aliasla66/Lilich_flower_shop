package il.cshaifasweng.OCSFMediatorExample.entities;

import javax.naming.Name;
import javax.persistence.*;
import java.io.Serializable;
import java.util.List;
/*
@Entity
@Table(name = "cart_table")*/
public class Cart implements Serializable {
 /*   @Id
    private int cartID;
    @Column(name = "Total_price_discount")
    private int totalpriceDiscount;
    @Column(name = "Total_price")
    private int TotalPrice;
    @OneToOne(mappedBy = "accCart")
    private Account cartAccount;
    @ManyToMany
    @JoinTable(
            name = "products_cart",
            joinColumns = @JoinColumn(name = "cart_ID", referencedColumnName = "cartID"),
            inverseJoinColumns = @JoinColumn(name = "product_ID", referencedColumnName = "id")
    )
    private List<Product> cartProducts;

    public Cart() {
    }

    public Cart(int cartID, int totalpriceDiscount, int totalPrice, List<Product> cartProducts) {
        this.cartID = cartID;
        this.totalpriceDiscount = totalpriceDiscount;
        TotalPrice = totalPrice;
        this.cartProducts = cartProducts;
    }

    public int getCartID() {
        return cartID;
    }

    public void setCartID(int cartID) {
        this.cartID = cartID;
    }

    public int getTotalpriceDiscount() {
        return totalpriceDiscount;
    }

    public void setTotalpriceDiscount(int totalpriceDiscount) {
        this.totalpriceDiscount = totalpriceDiscount;
    }

    public int getTotalPrice() {
        return TotalPrice;
    }

    public void setTotalPrice(int totalPrice) {
        TotalPrice = totalPrice;
    }

    public Account getCartAccount() {
        return cartAccount;
    }

    public void setCartAccount(Account cartAccount) {
        this.cartAccount = cartAccount;
    }
/*
    public List<Product> getCartProducts() {
        return cartProducts;
    }

    public void setCartProducts(List<Product> cartProducts) {
        this.cartProducts = cartProducts;
    }*/
}