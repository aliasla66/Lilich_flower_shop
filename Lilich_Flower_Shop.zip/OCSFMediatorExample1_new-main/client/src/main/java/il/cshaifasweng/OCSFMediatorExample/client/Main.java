package il.cshaifasweng.OCSFMediatorExample.client;
import il.cshaifasweng.OCSFMediatorExample.entities.Product;
public class Main {

	public static void main(String[] args) {
		App.main(args);
	}

}
