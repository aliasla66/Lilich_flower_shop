package il.cshaifasweng.OCSFMediatorExample.client;

public class catalog_flag {
    public static int getFlagg() {
        return flagg;
    }

    public static void setFlagg(int flagg) {
        catalog_flag.flagg = flagg;
    }

    public static int flagg=0;
}
